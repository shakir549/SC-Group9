package com.university.controller;

import com.university.dao.*;
import com.university.model.*;

import java.io.File;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

/**
 * Controller for handling user-related operations.
 * Acts as an intermediary between the UI and the data access layer.
 */
public class UserController {
    private static UserController instance;
    private final UserDAO userDAO;
    private final SubmissionDAO submissionDAO;
    private final ScheduleDAO scheduleDAO;
    private final DeadlineDAO deadlineDAO;
    private final NotificationDAO notificationDAO;
    private final ProjectVersionDAO projectVersionDAO;
    private User currentUser;

    // Private constructor for Singleton pattern
    private UserController() {
        this.userDAO = new UserDAO();
        this.submissionDAO = new SubmissionDAO();
        this.scheduleDAO = new ScheduleDAO();
        this.deadlineDAO = new DeadlineDAO();
        this.notificationDAO = new NotificationDAO();
        this.projectVersionDAO = new ProjectVersionDAO();
    }

    public static synchronized UserController getInstance() {
        if (instance == null) {
            instance = new UserController();
        }
        return instance;
    }

    public User login(String username, String password, Role role) {
        User user = userDAO.getUserByUsernameAndRole(username, role);
        if (user != null && user.getPassword().equals(password)) {
            currentUser = user;
            return user;
        }
        return null;
    }

    public void logout() {
        currentUser = null;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public User register(String username, String password, String fullName, String email, Role role) {
        if (userDAO.getUserByUsernameAndRole(username, role) != null) {
            return null;
        }
        User newUser = new User(0, username, password, fullName, email, role);
        int generatedId = userDAO.createUser(newUser);
        if (generatedId > 0) {
            newUser.setId(generatedId);
            return newUser;
        }
        return null;
    }

    public List<User> getUsersByRole(Role role) {
        return userDAO.getUsersByRole(role);
    }

    public List<User> getAllUsers() {
        return userDAO.getAllUsers();
    }

    public boolean updateUser(User user) {
        return userDAO.updateUser(user);
    }

    public boolean deleteUser(int userId) {
        return userDAO.deleteUser(userId);
    }

    public boolean submitProject(User loggedInUser, Object projectFromForm, File file) {
        if (loggedInUser == null || projectFromForm == null || file == null) {
            return false;
        }
        Submission submission = new Submission();
        submission.setProject((Project) projectFromForm);
        submission.setStudent(loggedInUser);
        submission.setDescription("My first draft");
        submission.setVersion(1);
        submission.setStatus(Submission.Status.PENDING);
        submission.setFilePath(file.getAbsolutePath());

        boolean result = submissionDAO.insertSubmission(submission, file);
        
        if (result) {
            // Notify the supervisor about the new submission
            sendNotification(submission.getProject().getSupervisor().getId(), 
                             "New submission for project: " + submission.getProject().getTitle()); // Use getTitle() instead of getName()
        }
        return result;
    }

    public void addSchedule(Schedule schedule) {
        scheduleDAO.addSchedule(schedule);
    }

    public List<Schedule> getSchedulesByProject(int projectId) {
        return scheduleDAO.getSchedulesByProject(projectId);
    }

    public void defineDeadline(Deadline deadline) {
        deadlineDAO.setDeadline(deadline);
    }

    public List<Notification> getNotifications(int userId) {
        return notificationDAO.getUserNotifications(userId);
    }

    public void sendNotification(int userId, String message) {
        // Create the notification object
        Notification notification = new Notification(userId, message, "Unread", new Timestamp(new Date().getTime()));

        // Add the notification to the database
        notificationDAO.addNotification(notification);

        // Log notification sending for debugging
        System.out.println("Notification sent to user " + userId + ": " + message);
    }

    public List<ProjectVersion> getProjectVersions(int submissionId) {
        return projectVersionDAO.getVersionsBySubmission(submissionId);
    }
}
