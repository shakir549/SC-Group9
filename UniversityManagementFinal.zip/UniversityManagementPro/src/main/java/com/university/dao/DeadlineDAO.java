package com.university.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.university.model.Deadline;
import com.university.util.DatabaseConnection;

public class DeadlineDAO {
    public void setDeadline(Deadline deadline) {
        try (Connection conn = DatabaseConnection.fetchConnection()) {
            String sql = "INSERT INTO deadlines (project_id, deadline_date, description) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, deadline.getProjectId());
             ps.setDate(2, new java.sql.Date(deadline.getDeadlineDate().getTime()));
            ps.setString(3, deadline.getDescription());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

