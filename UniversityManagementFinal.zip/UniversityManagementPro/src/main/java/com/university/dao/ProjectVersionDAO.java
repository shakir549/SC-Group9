package com.university.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.university.model.ProjectVersion;
import com.university.util.DatabaseConnection;
public class ProjectVersionDAO {
    public List<ProjectVersion> getVersionsBySubmission(int submissionId) {
        List<ProjectVersion> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.fetchConnection()) {
            String sql = "SELECT * FROM project_versions WHERE submission_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, submissionId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ProjectVersion v = new ProjectVersion(
                    rs.getInt("submission_id"),
                    rs.getInt("version_number"),
                    rs.getString("file_path"),
                    rs.getTimestamp("upload_date")
                );
                v.setVersionId(rs.getInt("version_id"));
                list.add(v);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}