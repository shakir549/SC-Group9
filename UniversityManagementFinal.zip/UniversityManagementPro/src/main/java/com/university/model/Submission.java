package com.university.model;

import java.util.Date;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Represents a project submission in the system.
 */
public class Submission {

    public enum Status {
        PENDING, APPROVED, REJECTED
    }

    private static final Logger LOGGER = Logger.getLogger(Submission.class.getName());

    private int id;
    private Project project;
    private User student;
    private String filePath;
    private String description;
    private Date submissionDate;
    private int version;
    private Status status;
    private byte[] fileData;

    /**
     * Default constructor initializes default values.
     */
    public Submission() {
        this.submissionDate = new Date();
        this.version = 1;
        this.status = Status.PENDING;

        
    }

    /*
     * Constructor with essential fields.
     *
     * @param project     the project being submitted
     * @param student     the student submitting
     * @param filePath    path to the submitted file
     * @param fileData    actual file content as byte array
     * @param description submission description
     */
    public Submission(Project project, User student, String filePath, byte[] fileData, String description) {
        this();
        this.project = project;
        this.student = student;
        setFilePath(filePath);
        setFileData(fileData);
        this.description = description;
    }

    /**
     * Full constructor with validation.
     */
    public Submission(int id, Project project, User student, String filePath, String description, Date submissionDate, int version, Status status, byte[] fileData) {
        this.id = id;
        this.project = project;
        this.student = student;
        setFilePath(filePath);
       
        this.description = description;
        this.submissionDate = submissionDate != null ? submissionDate : new Date();
        this.version = Math.max(version, 1);
        this.status = status != null ? status : Status.PENDING;
        
    }

    // Getters and Setters with validation
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public User getStudent() {
        return student;
    }

    public void setStudent(User student) {
        this.student = student;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        if (filePath != null && !filePath.trim().isEmpty()) {
            this.filePath = filePath;
        } else {
            LOGGER.log(Level.WARNING, "⚠️ Invalid file path provided!");
        }
    }

    public byte[] getFileData() {
        return fileData;
    }

    public void setFileData(byte[] fileData) {
        if (fileData != null && fileData.length > 0) {
            this.fileData = fileData;
        } else {
            LOGGER.log(Level.WARNING, "⚠️ Invalid file data provided!");
        }
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getSubmissionDate() {
        return submissionDate;
    }

    public void setSubmissionDate(Date submissionDate) {
        if (submissionDate != null) {
            this.submissionDate = submissionDate;
        } else {
            LOGGER.log(Level.WARNING, "⚠️ Submission date cannot be null. Defaulting to current date.");
        }
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        if (version > 0) {
            this.version = version;
        } else {
            LOGGER.log(Level.WARNING, "⚠️ Invalid version number provided. Keeping previous version.");
        }
    }

    public void updateVersion() {
        this.version++;
        LOGGER.info("✅ Version updated to " + version);
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        if (status != null) {
            this.status = status;
        } else {
            LOGGER.log(Level.WARNING, "⚠️ Invalid status provided. Keeping previous status.");
        }
    }

    @Override
    public String toString() {
        return "Submission{" +
                "id=" + id +
                ", project=" + (project != null ? project.getTitle() : "None") +
                ", student=" + (student != null ? student.getUsername() : "None") +
                ", filePath='" + filePath + '\'' +
                ", description='" + description + '\'' +
                ", submissionDate=" + submissionDate +
                ", version=" + version +
                ", status=" + status +
                ", fileDataSize=" + (fileData != null ? fileData.length + " bytes" : "No File") +
                '}';
    }
}