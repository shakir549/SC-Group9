package com.university.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Represents a project in the system.
 * Contains project information and relationships to students and supervisors.
 */
public class Project {
    private int id;
    private String title; // Project Title
    private String description; // Project Description
    private User supervisor; // Project Supervisor
    private List<User> students; // List of students assigned to the project
    private Date deadline; // Project Deadline
    private String status; // Project status ("Pending", "In Progress", "Completed", "Rejected")
    
    // Default constructor
    public Project() {
        this.students = new ArrayList<>();
    }
    
    // Constructor with basic fields
    public Project(String title, String description, User supervisor, Date deadline) {
        this.title = title;
        this.description = description;
        this.supervisor = supervisor;
        this.deadline = deadline;
        this.status = "Pending";
        this.students = new ArrayList<>();
    }
    
    // Full constructor
    public Project(int id, String title, String description, User supervisor, Date deadline, String status) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.supervisor = supervisor;
        this.deadline = deadline;
        this.status = status;
        this.students = new ArrayList<>();
    }
    
    // Getters and setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getTitle() { // Returns the project title
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public User getSupervisor() {
        return supervisor;
    }
    
    public void setSupervisor(User supervisor) {
        this.supervisor = supervisor;
    }
    
    public List<User> getStudents() {
        return students;
    }
    
    public void setStudents(List<User> students) {
        this.students = students;
    }
    
    public void addStudent(User student) {
        if (!students.contains(student) && student.getRole() == Role.STUDENT) {
            students.add(student);
        }
    }
    
    public void removeStudent(User student) {
        students.remove(student);
    }
    
    public Date getDeadline() {
        return deadline;
    }
    
    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }


    // Getter for the project title
    public String getName() {
        return title;
    }

  
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    @Override
    public String toString() {
        return "Project{" +
                "id=" + id +
                ", title='" + title + '\'' + // Ensure title is displayed correctly
                ", supervisor=" + (supervisor != null ? supervisor.getUsername() : "none") +
                ", students=" + students.size() +
                ", deadline=" + deadline +
                ", status='" + status + '\'' +
                '}';
    }
}
