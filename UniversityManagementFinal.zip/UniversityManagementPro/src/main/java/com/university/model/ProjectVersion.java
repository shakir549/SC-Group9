package com.university.model;
import java.sql.Timestamp;
public class ProjectVersion {
    private int versionId;
    private int submissionId;
    private int versionNumber;
    private String filePath;
    private Timestamp uploadDate;

    public ProjectVersion(int submissionId, int versionNumber, String filePath, Timestamp uploadDate) {
        this.submissionId = submissionId;
        this.versionNumber = versionNumber;
        this.filePath = filePath;
        this.uploadDate = uploadDate;
    }

    public int getVersionId() { return versionId; }
    public void setVersionId(int versionId) { this.versionId = versionId; }
    public int getSubmissionId() { return submissionId; }
    public int getVersionNumber() { return versionNumber; }
    public String getFilePath() { return filePath; }
    public Timestamp getUploadDate() { return uploadDate; }
}
