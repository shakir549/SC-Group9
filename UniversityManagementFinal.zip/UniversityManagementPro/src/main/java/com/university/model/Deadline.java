package com.university.model;
import java.util.Date;
public class Deadline {
    private int deadlineId;
    private int projectId;
    private Date deadlineDate;
    private String description;

    public Deadline(int projectId, Date deadlineDate, String description) {
        this.projectId = projectId;
        this.deadlineDate = deadlineDate;
        this.description = description;
    }

    public int getDeadlineId() { return deadlineId; }
    public void setDeadlineId(int deadlineId) { this.deadlineId = deadlineId; }
    public int getProjectId() { return projectId; }
    public Date getDeadlineDate() { return deadlineDate; }
    public String getDescription() { return description; }
}