package com.university.model;

import java.sql.Timestamp;

public class Notification {
    private int notificationId; // Add the notification ID field
    private int userId;         // Add the user ID field (sender or recipient)
    private String subject;     // Add the subject field (optional)
    private String message;     // Add the message field
    private Timestamp sendDate; // Timestamp for when the notification was sent
    private String isRead;      // Add the status field (e.g., "Unread" or "Read")
    private String importance;  // Add the importance field (optional)

    // Constructor
    public Notification(int userId, String message, String isRead, Timestamp sendDate) {
        this.userId = userId;
        this.message = message;
        this.isRead = isRead;
        this.sendDate = sendDate;
    }

    // Getters and setters for each field
    public int getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(int notificationId) {
        this.notificationId = notificationId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getIsRead() {
        return isRead;
    }

    public void setIsRead(String isRead) {
        this.isRead = isRead;
    }

    public Timestamp getSendDate() {
        return sendDate;
    }

    public void setSendDate(Timestamp sendDate) {
        this.sendDate = sendDate;
    }

    public String getImportance() {
        return importance;
    }

    public void setImportance(String importance) {
        this.importance = importance;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
