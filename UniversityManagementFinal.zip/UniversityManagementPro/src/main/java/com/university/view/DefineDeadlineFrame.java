package com.university.view;

import javax.swing.*;
import java.awt.*;
import java.sql.Date;
import com.university.controller.UserController;
import com.university.model.Deadline;

public class DefineDeadlineFrame extends JFrame {
    public DefineDeadlineFrame(int projectId) {
        setTitle("Define Project Deadline");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(4, 1));
        JLabel dateLabel = new JLabel("Deadline (yyyy-MM-dd):");
        JTextField dateField = new JTextField();
        JLabel descLabel = new JLabel("Description:");
        JTextField descField = new JTextField();
        JButton submitButton = new JButton("Set Deadline");

        submitButton.addActionListener(e -> {
            try {
                Date deadlineDate = Date.valueOf(dateField.getText());
                String desc = descField.getText();
                Deadline deadline = new Deadline(projectId, deadlineDate, desc);
                UserController.getInstance().defineDeadline(deadline);
                JOptionPane.showMessageDialog(this, "Deadline set successfully");
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid date format.");
            }
        });

        panel.add(dateLabel);
        panel.add(dateField);
        panel.add(descLabel);
        panel.add(descField);
        panel.add(submitButton);
        add(panel);
        setVisible(true);
    }
}